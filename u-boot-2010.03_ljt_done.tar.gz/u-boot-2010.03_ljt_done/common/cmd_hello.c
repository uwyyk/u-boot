
#include <common.h>
#include <command.h>

int do_hello (cmd_tbl_t *cmdtp, int flag, int argc, char *argv[])
{
    if (argc < 2) {
        printf("Hello world!\n");
        return 0;
    }

    printf("Hello %s!\n", argv[1]);
            
    return 0;
}

U_BOOT_CMD(
	hello,	2,	1,	do_hello,
	"print hello world!",
	"enter 'hello' command to print 'hello world'\n"
);

