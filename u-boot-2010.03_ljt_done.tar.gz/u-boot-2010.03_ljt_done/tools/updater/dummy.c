volatile int __dummy = 0xDEADBEEF;
